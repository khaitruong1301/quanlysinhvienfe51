

// var renderTitleH1 = function(title) {
//     var tagBody =  document.querySelector('body');
//     tagBody.innerHTML = `<h1>${title}</h1>`
// }


// var renderTitleDiv = function (title) {
//     var tagBody =  document.querySelector('body');
//     tagBody.innerHTML = `<div style="color:red">${title}</div>`

// }



// var main = function (callback) {

//     callback('Khải');
//     // renderTitleH1('khải 123')
// }


// main(renderTitleH1);